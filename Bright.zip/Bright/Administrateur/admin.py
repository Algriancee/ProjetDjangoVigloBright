from django.contrib import admin

from .models import Cour



admin.site.register(Cour)
# Register your models here.

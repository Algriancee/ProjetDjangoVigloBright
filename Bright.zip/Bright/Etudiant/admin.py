from django.contrib import admin
from .models import Soumission

admin.site.register(Soumission)
# Register your models here.

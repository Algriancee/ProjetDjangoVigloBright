from django.contrib import admin
from .models import User, Devoir



admin.site.register(User)
admin.site.register(Devoir)
# Register your models here.
